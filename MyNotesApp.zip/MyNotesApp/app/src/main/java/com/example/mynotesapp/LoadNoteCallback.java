package com.example.mynotesapp;

import java.util.ArrayList;

public interface LoadNoteCallback {
    void preExecute();
    void postExecute(ArrayList<Note> notes);
}
