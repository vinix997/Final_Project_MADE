package com.example.mynotesapp;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {
    private ArrayList<Note> listNotes = new ArrayList<>();
    private AppCompatActivity activity;

    public NoteAdapter(AppCompatActivity activity) {
        this.activity = activity;
    }
    public void setListNotes (ArrayList<Note> listNotes)
    {
        if(listNotes.size() > 0)
        {
            this.listNotes.clear();
        }
        this.listNotes.addAll(listNotes);
        notifyDataSetChanged();
    }
    @NonNull
    @Override
    public NoteAdapter.NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.items_note,parent,false);
        return new NoteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteAdapter.NoteViewHolder holder, int position) {
        holder.tvDescription.setText(listNotes.get(position).getDescription());
        holder.tvDate.setText(listNotes.get(position).getDate());
        holder.tvTitle.setText(listNotes.get(position).getTitle());
        holder.cvNote.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Intent intent = new Intent(activity, NoteAddUpdateActivity.class);
                intent.putExtra(NoteAddUpdateActivity.EXTRA_POSITION,position);
                intent.putExtra(NoteAddUpdateActivity.EXTRA_NOTE,listNotes.get(position));
                activity.startActivityForResult(intent,NoteAddUpdateActivity.REQUEST_UPDATE);

            }
        }));
    }

    @Override
    public int getItemCount() {
        return listNotes.size();
    }

    public ArrayList<Note> getListNotes() {
        return listNotes;
    }

    public class NoteViewHolder extends RecyclerView.ViewHolder{
        final TextView tvTitle, tvDescription, tvDate;
        final CardView cvNote;
        public NoteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_item_title);
            tvDescription = itemView.findViewById(R.id.tv_item_description);
            tvDate = itemView.findViewById(R.id.tv_item_date);
            cvNote = itemView.findViewById(R.id.cv_item_note);
        }
    }
    public void addItem(Note note)
    {
        this.listNotes.add(note);
        notifyItemInserted(listNotes.size() -1);
    }
    public void updateItem(int position,Note note)
    {
        this.listNotes.set(position,note);
        notifyItemChanged(position,note);
    }
    public void removeItem(int position)
    {
        this.listNotes.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,listNotes.size());
    }
}
